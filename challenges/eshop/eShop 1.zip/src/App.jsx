import { useState } from 'react'
import { Routes, Route, useNavigate } from 'react-router-dom'
import products from './products'
import ProductDetail from './ProductDetail'
import './App.css'

function ProductList({ search, setSearch, onAddToCart }) {
  const navigate = useNavigate();
  const filteredProducts = products.filter(
    (p) =>
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.description.toLowerCase().includes(search.toLowerCase())
  );
  return (
    <div className="eshop-container">
      <aside className="eshop-sidebar">
        <input
          type="text"
          placeholder="Search products..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="eshop-search"
        />
      </aside>
      <main className="eshop-main">
        <h1>Automobile Spare Parts</h1>
        <div className="eshop-product-list">
          {filteredProducts.map(product => (
            <div
              key={product.id}
              className="eshop-product-card"
              style={{ cursor: 'pointer', position: 'relative' }}
              onClick={() => navigate(`/product/${product.id}`)}
            >
              <h2>{product.name}</h2>
              <p>{product.description}</p>
              <div className="eshop-cost">${product.cost.toFixed(2)}</div>
              <button
                className="eshop-add-cart"
                style={{ position: 'absolute', top: 10, right: 10 }}
                onClick={e => {
                  e.stopPropagation();
                  onAddToCart(product);
                }}
              >Add to Cart</button>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}

function Cart({ cart }) {
  const total = cart.reduce((sum, item) => sum + item.cost * item.qty, 0);
  return (
    <aside className="eshop-sidebar" style={{ background: '#f1f1f7', color: '#232946', minWidth: 220 }}>
      <h2>Shop Cart</h2>
      {cart.length === 0 ? <div>No items in cart.</div> : (
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {cart.map(item => (
            <li key={item.id} style={{ marginBottom: 8 }}>
              {item.name} x{item.qty} <span style={{ float: 'right' }}>${(item.cost * item.qty).toFixed(2)}</span>
            </li>
          ))}
        </ul>
      )}
      <hr />
      <div style={{ fontWeight: 'bold', fontSize: '1.1rem' }}>Total: ${total.toFixed(2)}</div>
    </aside>
  );
}

function App() {
  const [search, setSearch] = useState("");
  const [cart, setCart] = useState([]);

  const handleAddToCart = (product) => {
    setCart(prev => {
      const found = prev.find(item => item.id === product.id);
      if (found) {
        return prev.map(item => item.id === product.id ? { ...item, qty: item.qty + 1 } : item);
      } else {
        return [...prev, { ...product, qty: 1 }];
      }
    });
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'row-reverse' }}>
      <Cart cart={cart} />
      <div style={{ flex: 1 }}>
        <Routes>
          <Route path="/" element={<ProductList search={search} setSearch={setSearch} onAddToCart={handleAddToCart} />} />
          <Route path="/product/:id" element={<ProductDetail />} />
        </Routes>
      </div>
    </div>
  );
}

export default App
