import { useParams, Link } from 'react-router-dom'
import products from './products'
import './App.css'

function ProductDetail() {
  const { id } = useParams();
  const product = products.find(p => p.id === Number(id));
  if (!product) {
    return (
      <div className="eshop-main">
        <h2>Product not found</h2>
        <Link to="/">Back to products</Link>
      </div>
    );
  }
  return (
    <div className="eshop-main">
      <Link to="/" style={{ textDecoration: 'none', color: '#3867d6' }}>&larr; Back to products</Link>
      <div className="eshop-product-card" style={{ maxWidth: 500, margin: '2rem auto' }}>
        <h1>{product.name}</h1>
        <p>{product.description}</p>
        <div className="eshop-cost" style={{ fontSize: '1.5rem' }}>${product.cost.toFixed(2)}</div>
      </div>
    </div>
  );
}

export default ProductDetail
