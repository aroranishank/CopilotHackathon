// Dummy data for 100 automobile spare parts
const products = [
  {
    id: 1,
    name: "Brake Pad Set",
    description: "High-quality ceramic brake pads for smooth stopping.",
    cost: 45.99
  },
  {
    id: 2,
    name: "Oil Filter",
    description: "Premium oil filter for extended engine life.",
    cost: 12.49
  },
  {
    id: 3,
    name: "Spark Plug",
    description: "Iridium spark plug for improved ignition.",
    cost: 8.99
  },
  {
    id: 4,
    name: "Air Filter",
    description: "High-flow air filter for better performance.",
    cost: 15.99
  },
  {
    id: 5,
    name: "Alternator",
    description: "Reliable alternator for consistent power supply.",
    cost: 129.99
  },
  {
    id: 6,
    name: "Timing Belt",
    description: "Durable timing belt for precise engine timing.",
    cost: 59.99
  },
  {
    id: 7,
    name: "Fuel Pump",
    description: "Efficient fuel pump for optimal fuel delivery.",
    cost: 89.99
  },
  {
    id: 8,
    name: "Radiator",
    description: "Aluminum radiator for superior cooling.",
    cost: 110.00
  },
  {
    id: 9,
    name: "Headlight Bulb",
    description: "Bright LED headlight bulb for clear visibility.",
    cost: 22.50
  },
  {
    id: 10,
    name: "Windshield Wiper Blade",
    description: "All-season wiper blade for streak-free cleaning.",
    cost: 9.99
  },
  {
    id: 11,
    name: "Battery",
    description: "Long-lasting car battery with high cold cranking amps.",
    cost: 99.99
  },
  {
    id: 12,
    name: "Clutch Kit",
    description: "Complete clutch kit for smooth gear shifts.",
    cost: 175.00
  },
  {
    id: 13,
    name: "Shock Absorber",
    description: "Gas-charged shock absorber for a comfortable ride.",
    cost: 49.99
  },
  {
    id: 14,
    name: "Wheel Bearing",
    description: "Sealed wheel bearing for reduced friction.",
    cost: 34.99
  },
  {
    id: 15,
    name: "CV Joint",
    description: "High-strength CV joint for smooth power transfer.",
    cost: 54.99
  },
  {
    id: 16,
    name: "Exhaust Muffler",
    description: "Stainless steel muffler for quiet performance.",
    cost: 79.99
  },
  {
    id: 17,
    name: "Catalytic Converter",
    description: "Efficient catalytic converter for reduced emissions.",
    cost: 210.00
  },
  {
    id: 18,
    name: "Thermostat",
    description: "Precision thermostat for accurate temperature control.",
    cost: 18.99
  },
  {
    id: 19,
    name: "Water Pump",
    description: "Reliable water pump for consistent coolant flow.",
    cost: 44.99
  },
  {
    id: 20,
    name: "Power Steering Pump",
    description: "Smooth power steering pump for easy handling.",
    cost: 120.00
  },
  {
    id: 21,
    name: "Drive Belt",
    description: "Multi-rib drive belt for accessory operation.",
    cost: 19.99
  },
  {
    id: 22,
    name: "Ignition Coil",
    description: "High-voltage ignition coil for reliable starts.",
    cost: 29.99
  },
  {
    id: 23,
    name: "Control Arm",
    description: "Sturdy control arm for stable suspension.",
    cost: 65.00
  },
  {
    id: 24,
    name: "Tie Rod End",
    description: "Durable tie rod end for precise steering.",
    cost: 17.99
  },
  {
    id: 25,
    name: "Ball Joint",
    description: "Heavy-duty ball joint for smooth suspension movement.",
    cost: 21.99
  },
  {
    id: 26,
    name: "Oxygen Sensor",
    description: "Accurate oxygen sensor for optimal fuel mixture.",
    cost: 39.99
  },
  {
    id: 27,
    name: "Mass Air Flow Sensor",
    description: "Sensitive MAF sensor for efficient combustion.",
    cost: 55.00
  },
  {
    id: 28,
    name: "Throttle Body",
    description: "Precision throttle body for responsive acceleration.",
    cost: 99.00
  },
  {
    id: 29,
    name: "EGR Valve",
    description: "Reliable EGR valve for reduced emissions.",
    cost: 47.99
  },
  {
    id: 30,
    name: "Fuel Injector",
    description: "High-performance fuel injector for better mileage.",
    cost: 32.99
  },
  {
    id: 31,
    name: "Engine Mount",
    description: "Strong engine mount for reduced vibration.",
    cost: 27.99
  },
  {
    id: 32,
    name: "Transmission Mount",
    description: "Durable transmission mount for smooth shifting.",
    cost: 24.99
  },
  {
    id: 33,
    name: "Heater Core",
    description: "Efficient heater core for quick cabin heating.",
    cost: 69.99
  },
  {
    id: 34,
    name: "Blower Motor",
    description: "Quiet blower motor for effective air circulation.",
    cost: 49.99
  },
  {
    id: 35,
    name: "AC Compressor",
    description: "Powerful AC compressor for cool air.",
    cost: 159.99
  },
  {
    id: 36,
    name: "Condenser",
    description: "High-efficiency condenser for rapid cooling.",
    cost: 89.99
  },
  {
    id: 37,
    name: "Evaporator",
    description: "Reliable evaporator for moisture removal.",
    cost: 79.99
  },
  {
    id: 38,
    name: "Window Regulator",
    description: "Smooth window regulator for easy window operation.",
    cost: 42.99
  },
  {
    id: 39,
    name: "Door Lock Actuator",
    description: "Secure door lock actuator for safety.",
    cost: 29.99
  },
  {
    id: 40,
    name: "Mirror Glass",
    description: "Clear mirror glass for better visibility.",
    cost: 14.99
  },
  {
    id: 41,
    name: "Tail Light Assembly",
    description: "Bright tail light assembly for safe driving.",
    cost: 59.99
  },
  {
    id: 42,
    name: "Fog Light",
    description: "Powerful fog light for improved visibility in fog.",
    cost: 24.99
  },
  {
    id: 43,
    name: "Grille",
    description: "Stylish grille for enhanced front-end look.",
    cost: 39.99
  },
  {
    id: 44,
    name: "Bumper Cover",
    description: "Durable bumper cover for added protection.",
    cost: 89.99
  },
  {
    id: 45,
    name: "Fender",
    description: "Strong fender for wheel protection.",
    cost: 74.99
  },
  {
    id: 46,
    name: "Hood Latch",
    description: "Secure hood latch for safety.",
    cost: 19.99
  },
  {
    id: 47,
    name: "Trunk Strut",
    description: "Reliable trunk strut for easy trunk access.",
    cost: 16.99
  },
  {
    id: 48,
    name: "Tailgate Handle",
    description: "Sturdy tailgate handle for easy operation.",
    cost: 13.99
  },
  {
    id: 49,
    name: "Wheel Lug Nut",
    description: "Secure wheel lug nut for safe driving.",
    cost: 2.99
  },
  {
    id: 50,
    name: "Hubcap",
    description: "Stylish hubcap for wheel protection.",
    cost: 11.99
  },
  {
    id: 51,
    name: "Valve Stem",
    description: "Durable valve stem for tire inflation.",
    cost: 1.99
  },
  {
    id: 52,
    name: "Tire Pressure Sensor",
    description: "Accurate tire pressure sensor for safety.",
    cost: 34.99
  },
  {
    id: 53,
    name: "Jack Kit",
    description: "Complete jack kit for emergency tire changes.",
    cost: 29.99
  },
  {
    id: 54,
    name: "Floor Mat Set",
    description: "All-weather floor mat set for interior protection.",
    cost: 39.99
  },
  {
    id: 55,
    name: "Seat Cover Set",
    description: "Comfortable seat cover set for style and protection.",
    cost: 49.99
  },
  {
    id: 56,
    name: "Steering Wheel Cover",
    description: "Grip-enhancing steering wheel cover for comfort.",
    cost: 15.99
  },
  {
    id: 57,
    name: "Shift Knob",
    description: "Ergonomic shift knob for smooth gear changes.",
    cost: 12.99
  },
  {
    id: 58,
    name: "Pedal Pad Set",
    description: "Non-slip pedal pad set for safety.",
    cost: 9.99
  },
  {
    id: 59,
    name: "Sun Visor",
    description: "Adjustable sun visor for glare reduction.",
    cost: 19.99
  },
  {
    id: 60,
    name: "Rearview Mirror",
    description: "Wide-angle rearview mirror for better visibility.",
    cost: 17.99
  },
  {
    id: 61,
    name: "Interior Dome Light",
    description: "Bright interior dome light for cabin illumination.",
    cost: 7.99
  },
  {
    id: 62,
    name: "Glove Box Latch",
    description: "Secure glove box latch for storage safety.",
    cost: 6.99
  },
  {
    id: 63,
    name: "Cup Holder",
    description: "Convenient cup holder for beverages.",
    cost: 8.99
  },
  {
    id: 64,
    name: "Ashtray",
    description: "Removable ashtray for easy cleaning.",
    cost: 5.99
  },
  {
    id: 65,
    name: "Cigarette Lighter",
    description: "Universal cigarette lighter for vehicles.",
    cost: 4.99
  },
  {
    id: 66,
    name: "Fuse Set",
    description: "Comprehensive fuse set for electrical safety.",
    cost: 9.99
  },
  {
    id: 67,
    name: "Relay Switch",
    description: "Reliable relay switch for electrical circuits.",
    cost: 7.99
  },
  {
    id: 68,
    name: "Wiring Harness",
    description: "Complete wiring harness for easy installation.",
    cost: 49.99
  },
  {
    id: 69,
    name: "Horn",
    description: "Loud horn for safety and alerts.",
    cost: 14.99
  },
  {
    id: 70,
    name: "Antenna",
    description: "Flexible antenna for clear radio reception.",
    cost: 11.99
  },
  {
    id: 71,
    name: "GPS Tracker",
    description: "Accurate GPS tracker for vehicle security.",
    cost: 59.99
  },
  {
    id: 72,
    name: "Dash Cam",
    description: "HD dash cam for recording your drive.",
    cost: 69.99
  },
  {
    id: 73,
    name: "Bluetooth Adapter",
    description: "Wireless Bluetooth adapter for hands-free calls.",
    cost: 19.99
  },
  {
    id: 74,
    name: "USB Charger",
    description: "Fast USB charger for mobile devices.",
    cost: 9.99
  },
  {
    id: 75,
    name: "Aux Cable",
    description: "Durable aux cable for audio connectivity.",
    cost: 5.99
  },
  {
    id: 76,
    name: "Speaker Set",
    description: "High-fidelity speaker set for great sound.",
    cost: 49.99
  },
  {
    id: 77,
    name: "Amplifier",
    description: "Powerful amplifier for enhanced audio.",
    cost: 89.99
  },
  {
    id: 78,
    name: "Subwoofer",
    description: "Deep bass subwoofer for music lovers.",
    cost: 99.99
  },
  {
    id: 79,
    name: "Roof Rack",
    description: "Sturdy roof rack for extra cargo.",
    cost: 119.99
  },
  {
    id: 80,
    name: "Bike Rack",
    description: "Easy-mount bike rack for outdoor trips.",
    cost: 69.99
  },
  {
    id: 81,
    name: "Cargo Net",
    description: "Flexible cargo net for trunk organization.",
    cost: 12.99
  },
  {
    id: 82,
    name: "Tow Hook",
    description: "Heavy-duty tow hook for emergencies.",
    cost: 19.99
  },
  {
    id: 83,
    name: "Trailer Hitch",
    description: "Strong trailer hitch for towing.",
    cost: 89.99
  },
  {
    id: 84,
    name: "Mud Flap Set",
    description: "Protective mud flap set for cleaner rides.",
    cost: 24.99
  },
  {
    id: 85,
    name: "Splash Guard",
    description: "Durable splash guard for wheel wells.",
    cost: 17.99
  },
  {
    id: 86,
    name: "License Plate Frame",
    description: "Stylish license plate frame for your car.",
    cost: 9.99
  },
  {
    id: 87,
    name: "Car Cover",
    description: "Weatherproof car cover for protection.",
    cost: 59.99
  },
  {
    id: 88,
    name: "Wind Deflector",
    description: "Aerodynamic wind deflector for windows.",
    cost: 29.99
  },
  {
    id: 89,
    name: "Bug Shield",
    description: "Protective bug shield for the hood.",
    cost: 34.99
  },
  {
    id: 90,
    name: "Hood Scoop",
    description: "Functional hood scoop for engine cooling.",
    cost: 44.99
  },
  {
    id: 91,
    name: "Spoiler",
    description: "Sporty spoiler for improved aerodynamics.",
    cost: 79.99
  },
  {
    id: 92,
    name: "Decal Set",
    description: "Custom decal set for personal style.",
    cost: 14.99
  },
  {
    id: 93,
    name: "Emblem",
    description: "Shiny emblem for brand identity.",
    cost: 11.99
  },
  {
    id: 94,
    name: "Key Fob",
    description: "Remote key fob for convenience.",
    cost: 39.99
  },
  {
    id: 95,
    name: "Remote Starter",
    description: "Remote starter for easy engine start.",
    cost: 99.99
  },
  {
    id: 96,
    name: "Alarm System",
    description: "Advanced alarm system for security.",
    cost: 119.99
  },
  {
    id: 97,
    name: "Jump Starter",
    description: "Portable jump starter for emergencies.",
    cost: 69.99
  },
  {
    id: 98,
    name: "Fire Extinguisher",
    description: "Compact fire extinguisher for safety.",
    cost: 24.99
  },
  {
    id: 99,
    name: "First Aid Kit",
    description: "Comprehensive first aid kit for emergencies.",
    cost: 19.99
  },
  {
    id: 100,
    name: "Emergency Roadside Kit",
    description: "Complete roadside kit for breakdowns.",
    cost: 49.99
  }
];

export default products;
